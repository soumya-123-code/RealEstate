import prisma from "../lib/prisma.js";

// Advanced property search (Public)
export const getProperties = async (req, res) => {
  const {
    city, state, locality, propertyType, saleType, listingType, furnishingStatus,
    minPrice, maxPrice, bedroom, bathroom, minArea, maxArea,
    status, isFeatured, sort, page = 1, limit = 12,
  } = req.query;

  try {
    const whereClause = {
      ...(city && { city: { contains: city, mode: "insensitive" } }),
      ...(state && { state: { contains: state, mode: "insensitive" } }),
      ...(locality && { locality: { contains: locality, mode: "insensitive" } }),
      ...(propertyType && { propertyType }),
      ...(saleType && { saleType }),
      ...(listingType && { listingType }),
      ...(furnishingStatus && { furnishingStatus }),
      ...(bedroom && { bedroom: { gte: parseInt(bedroom) } }),
      ...(bathroom && { bathroom: { gte: parseInt(bathroom) } }),
      ...(status && { status }),
      ...(isFeatured === "true" && { isFeatured: true }),
      ...(minArea && { area: { gte: parseInt(minArea) } }),
      ...(maxArea && { area: { lte: parseInt(maxArea) } }),
    };

    // Fix: if both minPrice and maxPrice, use combined range
    if (minPrice && maxPrice) {
      whereClause.price = { gte: parseFloat(minPrice), lte: parseFloat(maxPrice) };
    } else if (minPrice) {
      whereClause.price = { gte: parseFloat(minPrice) };
    } else if (maxPrice) {
      whereClause.price = { lte: parseFloat(maxPrice) };
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Determine sort order
    let orderBy = { createdAt: "desc" };
    if (sort === "price_asc") orderBy = { price: "asc" };
    if (sort === "price_desc") orderBy = { price: "desc" };
    if (sort === "newest") orderBy = { createdAt: "desc" };
    if (sort === "popular") orderBy = { views: "desc" };
    if (sort === "area_asc") orderBy = { area: "asc" };
    if (sort === "area_desc") orderBy = { area: "desc" };

    const [properties, total] = await Promise.all([
      prisma.property.findMany({
        where: whereClause,
        orderBy,
        skip,
        take: parseInt(limit),
        include: {
          agent: {
            select: {
              id: true,
              user: { select: { id: true, username: true, avatar: true, phone: true } },
            },
          },
        },
      }),
      prisma.property.count({ where: whereClause }),
    ]);

    res.status(200).json({
      properties,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to get properties!" });
  }
};

// Get unique cities/states for filters (Public)
export const getFilterOptions = async (req, res) => {
  try {
    const cities = await prisma.property.findMany({
      where: { status: "AVAILABLE" },
      select: { city: true, state: true },
      distinct: ["city", "state"],
      orderBy: { city: "asc" },
    });

    const propertyTypes = ["APARTMENT", "HOUSE", "VILLA", "PLOT", "COMMERCIAL", "LAND", "FARMHOUSE", "PENTHOUSE", "STUDIO"];

    res.status(200).json({
      cities,
      propertyTypes,
      saleTypes: ["SALE", "RENT", "LEASE"],
      listingTypes: ["NEW", "RESALE"],
      furnishingStatuses: ["FURNISHED", "SEMI_FURNISHED", "UNFURNISHED"],
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to get filter options!" });
  }
};

// Get single property (Public)
export const getProperty = async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const property = await prisma.property.findUnique({
      where: { id },
      include: {
        agent: {
          select: {
            id: true,
            experience: true,
            specializations: true,
            rating: true,
            totalSales: true,
            user: { select: { id: true, username: true, avatar: true, phone: true, email: true } },
          },
        },
      },
    });

    if (!property) {
      return res.status(404).json({ message: "Property not found!" });
    }

    // Increment view count
    await prisma.property.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    res.status(200).json(property);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to get property!" });
  }
};

// Generate WhatsApp booking link (Authenticated)
export const generateWhatsAppLink = async (req, res) => {
  const tokenUserId = req.userId;
  const { propertyId } = req.body;

  try {
    const property = await prisma.property.findUnique({ where: { id: propertyId } });
    if (!property) return res.status(404).json({ message: "Property not found!" });

    const user = await prisma.user.findUnique({ where: { id: tokenUserId } });

    if (property.status === "SOLD") return res.status(400).json({ message: "This property is already sold!" });
    if (property.status === "RENTED") return res.status(400).json({ message: "This property is currently rented!" });

    const existingBooking = await prisma.booking.findFirst({
      where: { userId: tokenUserId, propertyId },
    });

    if (!existingBooking) {
      await prisma.booking.create({
        data: { userId: tokenUserId, propertyId, bookingStatus: "CONTACTED", remarks: "User contacted via WhatsApp" },
      });
    }

    // Create notifications
    const { createNotification } = await import("./notification.controller.js");
    const admins = await prisma.user.findMany({ where: { role: "ADMIN" } });
    for (const admin of admins) {
      await createNotification(admin.id, "New Property Inquiry", `${user.username} is interested in "${property.title}"`, "INQUIRY", "/admin/bookings");
    }

    const io = req.app.get("io");
    if (io) {
      io.emit("newInquiry", { propertyId: property.id, propertyTitle: property.title, userId: user.id, username: user.username, timestamp: new Date().toISOString() });
    }

    const images = typeof property.images === "string" ? JSON.parse(property.images) : property.images;
    const message = `Hello! I'm interested in booking this property:\n\n*Property Details:*\n📍 *Title:* ${property.title}\n💰 *Price:* ₹${property.price}\n🏠 *Type:* ${property.propertyType} (${property.saleType})\n📐 *Area:* ${property.area} sq ft\n📌 *Location:* ${property.address}, ${property.city}, ${property.state}\n\n*My Details:*\n👤 *Name:* ${user.username}\n📧 *Email:* ${user.email}\n📱 *Phone:* ${user.phone || "Not provided"}`;
    const whatsappNumber = process.env.WHATSAPP_BUSINESS_NUMBER || "919876543210";
    const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

    res.status(200).json({ success: true, whatsappLink, message: "WhatsApp link generated successfully!", bookingId: existingBooking?.id || null });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to generate WhatsApp link!" });
  }
};

// Get user's bookings (Authenticated)
export const getMyBookings = async (req, res) => {
  const tokenUserId = req.userId;
  try {
    const bookings = await prisma.booking.findMany({
      where: { userId: tokenUserId },
      include: { property: true },
      orderBy: { createdAt: "desc" },
    });
    res.status(200).json(bookings);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to get bookings!" });
  }
};
