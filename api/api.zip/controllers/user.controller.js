import prisma from "../lib/prisma.js";
import bcrypt from "bcrypt";

// Public endpoint to get admin user for chat (no auth required)
export const getAdminUser = async (req, res) => {
  try {
    const admin = await prisma.user.findFirst({
      where: { role: "ADMIN" },
      select: {
        id: true,
        username: true,
        email: true,
        avatar: true,
        phone: true,
        role: true,
      },
    });

    if (!admin) {
      return res.status(404).json({ message: "Admin user not found" });
    }

    res.status(200).json(admin);
  } catch (err) {
    console.error("[ERROR] getAdminUser failed:", err);
    res.status(500).json({ message: "Failed to get admin user" });
  }
};

export const getUsers = async (req, res) => {
  try {
    console.log("[DEBUG] getUsers called");
    const { role, exclude } = req.query;
    const where = {};
    if (role && role !== 'all') {
      where.role = role;
    }
    if (exclude) {
      where.id = { not: parseInt(exclude) };
    }
    const users = await prisma.user.findMany({
      where,
      select: {
        id: true,
        username: true,
        email: true,
        avatar: true,
        phone: true,
        role: true,
        permissions: true,
        canAccessAdminPanel: true,
        passwordLoginEnabled: true,
        isActive: true,
        createdAt: true,
      },
    });
    console.log("[DEBUG] Found users:", users.length);
    res.status(200).json(users);
  } catch (err) {
    console.error("[ERROR] getUsers failed:", err);
    res.status(500).json({ message: "Failed to get users! " + err.message });
  }
};

export const getUser = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        username: true,
        email: true,
        avatar: true,
        phone: true,
        role: true,
        permissions: true,
        canAccessAdminPanel: true,
        passwordLoginEnabled: true,
        isActive: true,
        createdAt: true,
      },
    });
    res.status(200).json(user);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Failed to get user!" });
  }
};

export const updateUser = async (req, res) => {
  const id = parseInt(req.params.id);
  const tokenUserId = req.userId;
  const { password, avatar, ...inputs } = req.body;

  if (id !== tokenUserId) {
    return res.status(403).json({ message: "Not Authorized!" });
  }

  let updatedPassword = null;
  try {
    if (password) {
      updatedPassword = await bcrypt.hash(password, 10);
    }

    const updatedUser = await prisma.user.update({
      where: { id },
      data: {
        ...inputs,
        ...(updatedPassword && { password: updatedPassword }),
        ...(avatar && { avatar }),
      },
    });

    const { password: userPassword, ...rest } = updatedUser;

    res.status(200).json(rest);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Failed to update user!" });
  }
};

export const deleteUser = async (req, res) => {
  const id = parseInt(req.params.id);
  const tokenUserId = req.userId;

  if (id !== tokenUserId) {
    return res.status(403).json({ message: "Not Authorized!" });
  }

  try {
    await prisma.user.delete({
      where: { id },
    });
    res.status(200).json({ message: "User deleted" });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Failed to delete user!" });
  }
};
