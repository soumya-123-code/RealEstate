import jwt from "jsonwebtoken";

export const verifyToken = (req, res, next) => {
  // Support both cookie and Authorization header
  const token = req.cookies.token || req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Not Authenticated!" });
  }

  jwt.verify(token, process.env.JWT_SECRET_KEY, async (err, payload) => {
    if (err) {
      if (err.name === "TokenExpiredError") {
        return res.status(401).json({ message: "Token expired! Please login again." });
      }
      return res.status(403).json({ message: "Invalid token!" });
    }
    
    req.userId = payload.id;
    req.userRole = payload.role;
    req.isAdmin = payload.isAdmin;
    req.permissions = payload.permissions || [];
    req.canAccessAdminPanel = !!payload.canAccessAdminPanel;
    next();
  });
};

// Admin-only middleware
export const verifyAdmin = (req, res, next) => {
  const token = req.cookies.token || req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Not Authenticated!" });
  }

  jwt.verify(token, process.env.JWT_SECRET_KEY, async (err, payload) => {
    if (err) {
      if (err.name === "TokenExpiredError") {
        return res.status(401).json({ message: "Token expired!" });
      }
      return res.status(403).json({ message: "Invalid token!" });
    }

    const hasAdminPanelAccess = payload.role === "ADMIN" || (
      payload.role === "STAFF" &&
      (payload.canAccessAdminPanel || (payload.permissions || []).includes("ADMIN_PANEL"))
    );

    if (!hasAdminPanelAccess) {
      return res.status(403).json({ message: "Admin access required!" });
    }

    req.userId = payload.id;
    req.userRole = payload.role;
    req.isAdmin = payload.role === "ADMIN";
    req.permissions = payload.permissions || [];
    req.canAccessAdminPanel = !!payload.canAccessAdminPanel;
    next();
  });
};
