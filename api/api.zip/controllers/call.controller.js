import prisma from "../lib/prisma.js";

export const getCallLogs = async (req, res) => {
  const tokenUserId = parseInt(req.userId);
  const chatId = parseInt(req.params.chatId);

  try {
    const callLogs = await prisma.callLog.findMany({
      where: {
        chatId,
      },
      include: {
        caller: {
          select: { id: true, username: true, avatar: true },
        },
        receiver: {
          select: { id: true, username: true, avatar: true },
        },
      },
      orderBy: { startedAt: "desc" },
      take: 30,
    });

    res.status(200).json(callLogs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to get call logs!" });
  }
};

export const createCallLog = async (req, res) => {
  const tokenUserId = parseInt(req.userId);
  const { chatId, callerId, receiverId, callType, status, duration } = req.body;

  try {
    if (!chatId || !callerId || !receiverId) {
      return res.status(400).json({ message: "chatId, callerId, and receiverId are required" });
    }

    const callLog = await prisma.callLog.create({
      data: {
        chatId: parseInt(chatId),
        callerId: parseInt(callerId),
        receiverId: parseInt(receiverId),
        callType: callType || "audio",
        status: status || "missed",
        duration: duration || 0,
        endedAt: duration > 0 ? new Date() : null,
      },
      include: {
        caller: { select: { id: true, username: true, avatar: true } },
        receiver: { select: { id: true, username: true, avatar: true } },
      },
    });

    res.status(200).json(callLog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to create call log!" });
  }
};